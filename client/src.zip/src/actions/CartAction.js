import axios from 'axios'
import {ADD_TO_CART,EMTPY_CART,REMOVE_FROM_CART,SAVE_SHIPPING_INFO} from "../constants/Cartconstants"

// add to cart ; 
export const addItemToCart = (id,quantity=1)=>async(dispath)=>{
    const {data} = await axios.get(`/api/v1/${id}`);
    dispath({
        type:ADD_TO_CART,
        payload:{
            product:data.product._id,
            name:data.product.name,
            seller:data.product.brand.name,
            price:data.product.price,
            image:data.product.image[0].url,
            stock:data.product.stock,
            quantity
        }
    })
    localStorage.setItem('cartItems',JOSN.stringify(getState().cart.carItems));
}



export const removeItemsFromCart = (id)=>async(dispath,getState)=>{
    dispath({
        type:REMOVE_FROM_CART,
        payload:id
    })
    localStorage.setItem('cartItems',JSON.stringify(getState().cart.carItems));
}

export const emptycart = ()=>async(dispath,getState)=>{
    dispath({type:EMTPY_CART});
    localStorage.setItem('cartItems'.JSON.stringify(getState().cart.carItems));
}


export const saveShippingInfo = (data)=>async(dispath)=>{
    dispath({
        type:SAVE_SHIPPING_INFO,
        payload:data
    })
    localStorage.setItem('shippingInfo',JSON.stringify(data));
}