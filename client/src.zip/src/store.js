import { configureStore,combineReducers } from '@reduxjs/toolkit';
import { forgotPasswordReducer, profileReducer, userReducer, allUsersReducer, userDetaislReducer } from './reducers/userReducer';
import { newProductReducer, newReviewReducer, productDetailsReducer, ProductReducer, productReviewsReducer, reviewReducer } from './reducers/productReducer';
import { cartReducer } from './reducers/cartReducer';
import { saveForLaterReducer } from './reducers/SaveForLaterReducer';
import { AllorderReducer, myOrdersReducer, newOrderReducer, OrderDetailsReducer, OrderReducer, paymentStatusReducer } from './reducers/orderReducer';
import { wishlistReducer } from './reducers/wihlistReducer';

const reducer = combineReducers({
    user: userReducer,
    profile: profileReducer,
    forgotPassword: forgotPasswordReducer,
    products: ProductReducer,
    productDetails: productDetailsReducer,
    newReview: newReviewReducer,
    cart: cartReducer,
    saveForLater: saveForLaterReducer,
    newOrder: newOrderReducer,
    myOrders: myOrdersReducer,
    paymentStatus: paymentStatusReducer,
    orderDetails: OrderDetailsReducer,
    allOrders: AllorderReducer,
    order: OrderReducer,
    newProduct: newProductReducer,
    product: ProductReducer,
    users: allUsersReducer,
    userDetails: userDetaislReducer,
    reviews: productReviewsReducer,
    review: reviewReducer,
    wishlist: wishlistReducer,
});
let initialState = {
    cart: {
        cartItems: localStorage.getItem('cartItems')
            ? JSON.parse(localStorage.getItem('cartItems'))
            : [],
        shippingInfo: localStorage.getItem("shippingInfo")
            ? JSON.parse(localStorage.getItem("shippingInfo"))
            : {},
    },
    saveForLater: {
        saveForLaterItems: localStorage.getItem('saveForLaterItems')
            ? JSON.parse(localStorage.getItem('saveForLaterItems'))
            : [],
    },
    wishlist: {
        wishlistItems: localStorage.getItem('wishlistItems')
            ? JSON.parse(localStorage.getItem('wishlistItems'))
            : [],
    },
};

const store = configureStore({
    reducer: {
        reducer,
        initialState
    },
});

export default store