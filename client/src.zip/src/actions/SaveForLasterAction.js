import { REMOVE_FROM_SAVE_LATER,SAVE_FOR_LATER } from "../constants/saveForLaterconstants";

// save for Later
export const saveForLater = (id)=>async(dispath,getState)=>{
    const cartItemsaarr = getState().cart.cartItems;
    const product = cartItemsaarr.find((i)=>i.product==id);
    dispath({
        type:SAVE_FOR_LATER,
        payload:product
    })

    localStorage.setItem('saveForLaterItems',JSON.stringify(getState().saveForLater.saveforlaterItems))
}


export const removeFromSaveForLater  =(id)=>async(dispatch,getState)=>{
    dispatch({
        type:REMOVE_FROM_SAVE_LATER,
        payload:id
    })
    localStorage.setItem('saveForLaterItems',JSON.stringify(getState().saveforlaterItems.saveforlaterItems))
}