import React from 'react'

import { Link } from 'react-router-dom'
const Product = ({image,name,offer,tag}) => {
    return (
        <>
            <Link to="/products">
                <div>
                    <img draggable="false" className="w-full h-full object-contain" src={image} alt={name} />
                </div>
                <h2 >{name}</h2>
                <span> {offer}</span>
                <span >{tag}</span>
            </Link>
        </>
    )
}

export default Product