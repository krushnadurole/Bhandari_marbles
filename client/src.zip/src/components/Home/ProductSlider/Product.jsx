import { getDiscount } from '../../../utils/functions';
import StarIcon from '@mui/icons-material/Star';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { addToWishlist, removeFromWishlist } from '../../../actions/wishlistAction';
import { useSnackbar } from 'notistack';

const Product = (props) => {

    const { _id, name, images, ratings, numOfReviews, price, cuttedPrice } = props;

    const dispatch = useDispatch();
    const { enqueueSnackbar } = useSnackbar();

    const { wishlistItems } = useSelector((state) => state.wishlist);

    const itemInWishlist = wishlistItems.some((i) => i.product === _id);

    const addToWishlistHandler = () => {
        if (itemInWishlist) {
            dispatch(removeFromWishlist(_id));
            enqueueSnackbar("Remove From Wishlist", { variant: "success" });
        } else {
            dispatch(addToWishlist(_id));
            enqueueSnackbar("Added To Wishlist", { variant: "success" });
        }
    }

    return (
        <div className="flex flex-col items-center gap-2 px-2 py-6 relative">
            <Link to={`/product/${_id}`} >
                <div className="w-36 h-36">
                    <img draggable="false" src={images[0].url} alt={name} />
                </div>
                <h2 >{name.length > 50 ? `${name.substring(0, 50)}...` : name}</h2>
            </Link>
            <div className="flex flex-col gap-2 items-center">
                <span >
                    <span >{ratings.toFixed(1)} <StarIcon sx={{ fontSize: "14px" }} /></span>
                    <span>({numOfReviews.toLocaleString()})</span>
                </span>
                <div>
                    <span>₹{price.toLocaleString()}</span>
                    <span >₹{cuttedPrice.toLocaleString()}</span>
                    <span >{getDiscount(price, cuttedPrice)}%&nbsp;off</span>
                </div>
            </div>

            <span onClick={addToWishlistHandler} className={`${itemInWishlist ? "text-red-500" : "hover:text-red-500 text-gray-300"} absolute top-5 right-2 cursor-pointer`}><FavoriteIcon sx={{ fontSize: "16px" }} /></span>
        </div>
    );
};

export default Product;
