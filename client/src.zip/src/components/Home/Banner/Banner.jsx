import slider  from 'react-slick'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css"
import './Banner.css'

import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos'
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos'

import gadgetSale from '../../../assets/images/Banners/gadget-sale.jpg';
import kitchenSale from '../../../assets/images/Banners/kitchen-sale.jpg';
import poco from '../../../assets/images/Banners/poco-m4-pro.webp';
import realme from '../../../assets/images/Banners/realme-9-pro.webp';
import fashionSale from '../../../assets/images/Banners/fashionsale.jpg';
import oppo from '../../../assets/images/Banners/oppo-reno7.webp';
import Slider from 'react-slick';

export const PreviousBtn = ({className,onClick})=>{
    return(
        <div className={className} onClick={onClick}>
            <ArrowBackIosIcon/>
        </div>
    )
}

export const NextBtn = ({className,onClick})=>{
    return(
        <div className={className} onClick={onClick}>
            <ArrowForwardIosIcon/>
        </div>
    )
}

const Banner = ()=>{
    const settings = {
        prevArrow: <PreviousBtn/>,
        nextArrow: <NextBtn/>,
        autoplay:true,
        autoplayspeed:1000,
        infinte:true,
        dots:false,
        slideToShow:1,
        speed:500
    }
    const banners = [gadgetSale,kitchenSale,poco,fashionSale,realme,oppo]
    return(
        <>
        <section>
            <Slider {...settings}>
                {banners.map((el,i)=>(
                    <img draggable="false"className=''  src={el}  alt="banner" key={i}></img>
                ))}
            </Slider>
        </section>
        </>
    )
}
export default Banner;